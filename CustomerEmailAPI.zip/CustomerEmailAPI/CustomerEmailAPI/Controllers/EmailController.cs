﻿using CustomerEmail.Models;
using CustomerEmailAPI.Requests;
using EmailSend;
using EmailSend.Models;
using Microsoft.AspNetCore.Mvc;

namespace CustomerEmailAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private IConfiguration _configuration;


        public EmailController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        public async Task SendEmail(EmailRequest request)
        {
            var emailValues = new EmailValues()
            {
                Name = request.Name,
                EmailAddress = request.EmailAddress,
                Subject = request.Subject,
                Message = request.Message
            };

            var newEmailTrans = new SendEmailTransimission();
            Task.Run(() => newEmailTrans.SendEmailAsync(emailValues));
        }

        [HttpGet]
        public async Task<List<EmailLog>> GetLoggingData()
        {
            var newEmailTrans = new SendEmailTransimission();
            var data = await newEmailTrans.GetLogData();
            var log = new List<EmailLog>(data);
            return log;
        }
    }
}
