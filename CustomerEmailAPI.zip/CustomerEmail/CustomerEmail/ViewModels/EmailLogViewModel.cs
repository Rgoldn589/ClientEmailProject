﻿using CustomerEmail.Helper;
using CustomerEmail.Models;
using CustomerEmail.Views;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Net.Http;

namespace CustomerEmail.ViewModels
{
    public class EmailLogViewModel
    {
        public EmailLogView Window { get; set; }
        public List<EmailLog> Log {  get; set; }

        private RelayCommand _close;
        public RelayCommand Close
        {
            get
            {
                if (_close == null)
                {
                    _close = new RelayCommand(CloseForm, true);
                }

                return _close;
            }
        }

        public EmailLogViewModel()
        {
            GetData();
        }

        public async void GetData()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Get, "https://localhost:5091/api/email");
            var response = client.Send(request);
            var result = await response.Content.ReadAsStringAsync();
            Log = new List<EmailLog>(Newtonsoft.Json.JsonConvert.DeserializeObject<List<EmailLog>>(result));
        }

        private void CloseForm()
        {
            Window.Close();
        }
    }
}
