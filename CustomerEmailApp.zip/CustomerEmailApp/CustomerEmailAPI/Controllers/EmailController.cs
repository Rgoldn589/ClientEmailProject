﻿using CustomerEmailAPI.Requests;
using EmailSend;
using EmailSend.Models;
using Microsoft.AspNetCore.Mvc;

namespace CustomerEmailAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private IConfiguration _configuration;


        public EmailController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        public async Task<ActionResult>SendEmail(EmailRequest request)
        {

            var emailValues = new EmailValues()
            {
                Name = request.Name,
                EmailAddress = request.EmailAddress,
                Subject = request.Subject,
                Message = request.Message
            };

            var newEmailTrans = new SendEmailTransimission();
            await newEmailTrans.SendEmailAsync(emailValues);
            return Ok();
        }

        [HttpGet]
        public async Task<ActionResult<List<EmailLog>>> GetLoggingData()
        {
            var newEmailTrans = new SendEmailTransimission();
            var data = await newEmailTrans.GetLogData();            
            var log = new List<EmailLog>(data);
            return Ok(log);
        }
    }
}
