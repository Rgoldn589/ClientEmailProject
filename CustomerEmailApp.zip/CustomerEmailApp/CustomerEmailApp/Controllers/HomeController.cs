using System.Diagnostics;
using CustomerEmailApp.Models;
using Microsoft.AspNetCore.Mvc;
using EmailSend.Models;

namespace CustomerEmailApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private EmailValues _emailValues;
        private List<EmailLog> _emailLog;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            _emailValues = new EmailValues();
            return View(_emailValues);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public async Task<IActionResult> SendEmail([Bind("Name,EmailAddress,Subject,Message")] EmailValues emailValues)
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://localhost:5091/api/email");
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(emailValues, Newtonsoft.Json.Formatting.Indented);
            var content = new StringContent(json, null, "application/json");
            request.Content = content;
            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();
            return View(nameof(Index));
        } 

        public async Task<IActionResult> ViewLog()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Get, "https://localhost:5091/api/email");
            var response = await client.SendAsync(request);
            var result = await response.Content.ReadAsStringAsync();
            _emailLog = new List<EmailLog>(Newtonsoft.Json.JsonConvert.DeserializeObject<List<EmailLog>>(result));           
            return View(_emailLog);
        }

    }
}
