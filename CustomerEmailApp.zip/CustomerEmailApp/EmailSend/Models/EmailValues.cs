﻿using System.ComponentModel.DataAnnotations;

namespace EmailSend.Models
{
    public partial class EmailValues
    {
        public string? Name { get; set; } = string.Empty;// = "Ronald Goldner";

        [Required]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email Address")]
        public string? EmailAddress { get; set; } //= "Goldner.Ronald@gmail.com";

        [Required]
        public string? Subject { get; set; } //= "This is a Test Subject.";

        [Required]
        public string? Message { get; set; }//= "This is a test message.";

    }
}
