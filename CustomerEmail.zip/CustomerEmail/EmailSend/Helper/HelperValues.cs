﻿
namespace EmailSend.Helper
{
    public static class HelperValues
    {
        public const int MaxEmailAttempts = 3;
    }
}
