﻿using System.ComponentModel.DataAnnotations;

namespace EmailSend.Models
{
    public partial class EmailValues : BaseModel
    {
        public string? Name { get; set; } = string.Empty;

        [Required(ErrorMessage ="Email Address is required.")]
        [DataType(DataType.EmailAddress)]
        public string? EmailAddress { get; set; }

        [Required(ErrorMessage = "Subject is required.")]
        public string? Subject { get; set; }

        [Required(ErrorMessage = "Message is required.")]
        public string? Message { get; set; }

     

    }
}
