﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace EmailSend.Models
{
    public abstract class BaseModel : IDataErrorInfo
    {
        public string this[string columnName]
        {
            get
            {
                var results = new List<ValidationResult>();
                var context = new ValidationContext(this) { MemberName = columnName };
                Validator.TryValidateProperty(
                    GetType().GetProperty(columnName)?.GetValue(this),
                    context,
                    results);

                return results.Count > 0 ? results[0].ErrorMessage : null;
            }
        }

        public string Error => null;
    }
}
