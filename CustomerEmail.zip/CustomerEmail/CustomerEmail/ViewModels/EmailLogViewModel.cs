﻿using CustomerEmail.Helper;
using CustomerEmail.Models;
using CustomerEmail.Views;
using System.ComponentModel;
using System.Net.Http;


namespace CustomerEmail.ViewModels
{
    public class EmailLogViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged = null;
        public EmailLogView Window { get; set; }

        private List<EmailLog> log;
        public List<EmailLog> Log 
        {
            get { return log; }
            set
            {
                log = value;
                OnPropertyChanged(nameof(Log));           
            }
        }

        private RelayCommand _close;
        public RelayCommand Close
        {
            get
            {
                if (_close == null)
                {
                    _close = new RelayCommand(CloseForm, true);
                }

                return _close;
            }
        }

        public EmailLogViewModel()
        {
            GetData();

        }

        public async void GetData()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Get, "https://localhost:5091/api/email");
            var response = await client.SendAsync(request);
            var result = await response.Content.ReadAsStringAsync();
            Log = new List<EmailLog>(Newtonsoft.Json.JsonConvert.DeserializeObject<List<EmailLog>>(result));
        }

        private void CloseForm()
        {
            Window.Close();
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged == null)
                return;

            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
