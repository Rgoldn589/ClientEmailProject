﻿using CustomerEmail.Helper;
using CustomerEmail.Models;
using CustomerEmail.Views;
using EmailSend;
using System.Configuration;
using System.IO;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace CustomerEmail.ViewModels
{
    public class EmailLogViewModel
    {

        public EmailLogView Window { get; set; }

        public List<EmailLog> Log { get; set; } = new List<EmailLog>();

        private RelayCommand _close;
        public RelayCommand Close
        {
            get
            {
                if (_close == null)
                {
                    _close = new RelayCommand(CloseForm, true);
                }

                return _close;
            }
        }

        public EmailLogViewModel()
        {
            GetData();
        }

        public void GetData()
        {
            var newEmailTrans = new SendEmailTransimission();
            var data = newEmailTrans.GetLogData();
            Log = new List<EmailLog>(data);
        }

        private void CloseForm()
        {
            Window.Close();
        }
    }
}
