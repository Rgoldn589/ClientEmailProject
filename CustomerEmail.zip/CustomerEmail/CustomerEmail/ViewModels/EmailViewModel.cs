﻿using CustomerEmail.Helper;
using EmailSend.Models;
using CustomerEmail.Views;
using System.Windows;
using System.ComponentModel;
using System.Text.RegularExpressions;
using System.Net.Http;
using System.Windows.Controls;

namespace CustomerEmail.ViewModels
{
    public class EmailViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged = null;
        public EmailView Window { get; set; }

        EmailValues emailValues;
        public EmailValues NewEmailValues
        {
            get { return emailValues; }
            set
            {
                emailValues = value;
                OnPropertyChanged(nameof(NewEmailValues));
            }
        }

        public string errorMessage = string.Empty;
        public string ErrorMessage
        {
            get
            {
                return errorMessage;
            }

            set
            {
                errorMessage = value;
                OnPropertyChanged(nameof(ErrorMessage));
            }
        }

        private Visibility isError = Visibility.Hidden;
        public Visibility IsError
        {
            get
            {
                return isError;
            }

            set
            {
                isError = value;
                OnPropertyChanged(nameof(IsError));
            }
        }

        private RelayCommand _send;
        public RelayCommand Send
        {
            get
            {
                if (_send == null)
                {
                    _send = new RelayCommand(SendEmail, Validate);
                }

                return _send;
            }
        }

        private RelayCommand _close;
        public RelayCommand Close
        {
            get
            {
                if (_close == null)
                {
                    _close = new RelayCommand(CloseForm, true);
                }

                return _close;
            }
        }

        public EmailViewModel()
        {
            emailValues = new EmailValues();
        }

        private async void SendEmail()
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://localhost:5091/api/email");
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(NewEmailValues, Newtonsoft.Json.Formatting.Indented);
            var content = new StringContent(json, null, "application/json");
            request.Content = content;
            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();
            NewEmailValues = new EmailValues();
            MessageBox.Show("Email Sent.", "Success");
        }

        private void CloseForm()
        {
            Window.Close();
        }

        private bool Validate()
        {
            return NewEmailValues.EmailAddress != null
                && NewEmailValues.Subject != null
                && NewEmailValues.Message != null;
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged == null)
                return;

            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
