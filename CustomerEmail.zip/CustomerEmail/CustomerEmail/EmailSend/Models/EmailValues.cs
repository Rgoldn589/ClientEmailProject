﻿
namespace EmailSend.Models
{
    public partial class EmailValues 
    {
        public string? Name { get; set; } = string.Empty;

        public string? EmailAddress { get; set; }

        public string? Subject { get; set; } 

        public string? Message { get; set; }

    }
}
