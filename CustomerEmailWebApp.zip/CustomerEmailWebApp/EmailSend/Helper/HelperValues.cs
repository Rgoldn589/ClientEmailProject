﻿
namespace EmailSend.Helper
{
    public static class HelperValues
    {
        public const int MaxEmailAttempts = 3;
        public const string ConfigPath = "C:\\VSDevelopment\\CustomerEmail\\EmailSend";
    }
}
